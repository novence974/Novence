import { GoogleGenAI } from "@google/genai";
export class GeminiService {
  private static getAI() { return new GoogleGenAI({ apiKey: process.env.API_KEY }); }
  static async generateIcon(botName: string) {
    const ai = this.getAI();
    const prompt = `A professional Discord icon for "${botName}". Sleek, modern, futuristic, neon cyan and purple.`;
    const response = await ai.models.generateContent({ model: 'gemini-2.5-flash-image', contents: { parts: [{ text: prompt }] }, config: { imageConfig: { aspectRatio: "1:1" } } });
    for (const part of response.candidates[0].content.parts) { if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`; }
    throw new Error("No image data");
  }
  static async animateImage(imageBase64: string, motionPrompt: string, aspectRatio: '16:9' | '9:16' = '16:9') {
    const ai = this.getAI();
    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: motionPrompt || 'Cinematic movement',
      image: { imageBytes: imageBase64.split(',')[1], mimeType: 'image/png' },
      config: { numberOfVideos: 1, resolution: '720p', aspectRatio: aspectRatio }
    });
    while (!operation.done) { await new Promise(r => setTimeout(r, 10000)); operation = await ai.operations.getVideosOperation({ operation }); }
    const url = `${operation.response?.generatedVideos?.[0]?.video?.uri}&key=${process.env.API_KEY}`;
    const res = await fetch(url);
    const blob = await res.blob();
    return URL.createObjectURL(blob);
  }
}