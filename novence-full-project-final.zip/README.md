# Novence AI Studio
Full source code for Discord Icon and Video Animator.

## Deployment
1. Upload to GitHub.
2. Connect to Vercel.
3. Add API_KEY in environment variables.